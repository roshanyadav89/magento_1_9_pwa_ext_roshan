<?php
class Titan_PWA_Helper_Data extends Mage_Core_Helper_Abstract
{
    const S_IMAGE_TYPE       = 'image/png';
    const S_ICON_CONFIG_PATH = 'pwa_manifest/manifest/upload_icon';

	/**
	* @var array
	*/
    private $aManifestData = [];

    public function getData()
    {
        $this->aManifestData['name'] = Mage::getStoreConfig('general/store_information/name');
        $this->aManifestData['manifest_version'] = '2';
        $this->aManifestData['start_url']        = '/';

        $aIcons = $this->getIconArray();

        if(!empty($aIcons)) {
            $this->aManifestData['icons'] = $aIcons;
        }
        return $this->loadConfigurableOptions();
    }

	/**
	* @return void
	*/
    private function loadConfigurableOptions()
    {
        $aSettings = Mage::getStoreConfig('pwa_manifest/manifest');

        foreach ($aSettings as $sKey => $mSetting) {
            if (!is_array($mSetting)) {
                $this->aManifestData[$sKey] = $mSetting;
                continue;
            }
            $this->aManifestData[$sKey] = array_values($mSetting);
        }
        return $this->jsonSerialize();
    }

	/**
	* @return array
	*/
    public function getManifestData()
    {
        return $this->aManifestData;
    }

	/**
	* @return string
	*/
    public function jsonSerialize()
    {
        return $this->getManifestData();
    }

    /* ----------- ICON start ----------- */

	/**
	* @var array $aManifestIconSizes
	*/
    private $aManifestIconSizes = [
        72,
        96,
        128,
        144,
        152,
        192,
        384,
        512,
    ];

	/**
	* @param string $sScope
	*
	* @return string
	*/
    private function getStoragePath($sScope)
    {
        return Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA) . DS . 'manifest' . DS . $sScope . DS;
    }

	/**
	* @param string $sFileName
	* @param string $sSize
	*
	* @return string
	*/
    private function getResizedImageUrl($sFileName, $sSize, $sScope)
    {
        $sStoragePath  = $this->getStoragePath($sScope);

        $sBasePath = $sStoragePath . $sFileName;

        $sNewPath = $sStoragePath . $sSize . 'x' . $sSize . '_' . $sFileName;

        if (file_exists($sBasePath) && is_file($sBasePath) && !file_exists($sNewPath)) {
            $oImageObj = new Varien_Image($sBasePath);
            $oImageObj->constrainOnly(true);
            $oImageObj->keepAspectRatio(false);
            $oImageObj->keepFrame(false);
            $oImageObj->resize($sSize, $sSize);
            $oImageObj->save($sNewPath);
        }
        return Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA) . 'manifest' . DS . $sScope . DS . $sSize . 'x' . $sSize . '_' . $sFileName;
    }

	/**
	* @return array
	*/
    public function getIconArray()
    {
		/**
		* @var array<string,string> $aFilePath scope,filename
		*/
        $aFilePath = explode('/', Mage::getStoreConfig(self::S_ICON_CONFIG_PATH));

        $sScope    = $aFilePath[0];
        $sFileName = $aFilePath[1];

        $aIcons    = [];

        if (empty($sFileName)) {
            return $aIcons;
        }

        foreach ($this->aManifestIconSizes as $iIconSize) {
            $aIcons[] = [
                'src'   => $this->getResizedImageUrl($sFileName, $iIconSize, $sScope),
                'sizes' => $iIconSize . 'x' . $iIconSize,
                'type'  => self::S_IMAGE_TYPE,
            ];
        }
        return $aIcons;
    }
}