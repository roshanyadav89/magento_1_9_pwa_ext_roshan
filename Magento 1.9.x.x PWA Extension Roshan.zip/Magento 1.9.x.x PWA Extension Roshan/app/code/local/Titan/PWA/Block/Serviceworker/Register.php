<?php
class Titan_PWA_Block_Serviceworker_Register extends Mage_Core_Block_Template
{
    /**
    * Check if PWA features are enabled.
    *
    * @return bool
    */
    public function isEnabled(){
        return $this->getConfig()->isEnabled();
    }

    public function getVersionNumberPrefix(){
        return $this->getConfig()->getVersionNumberPrefix();
    }

    /**
    * Get the service worker JS url.
    *
    * @return string
    */

    public function getServiceworkerJsUrl(){
        $swJs = $this->getConfig()->getServiceworkerJs();
        return $this->_getUrlModel()->getDirectUrl($swJs);
    }

    /**
    * Get the configuration helper.
    *
    * @return Titan_PWA_Helper_Config
    */
    protected function getConfig(){
        return Mage::helper("pwa/config");
    }
}