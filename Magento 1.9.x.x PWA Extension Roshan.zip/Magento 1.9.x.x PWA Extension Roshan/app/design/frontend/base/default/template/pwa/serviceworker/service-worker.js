'use strict';

// @var Titan_PWA_Block_Serviceworker_Js $this

const version = '<?php echo $this->getVersion();?>';
//const offlinePage = '<?php echo $this->getOfflinePageUrl();?>';
//const urlBlacklist = <?php echo json_encode($this->getOfflineUrlBlacklist()) ?>;

// Functions
// #####################################

importScripts('https://storage.googleapis.com/workbox-cdn/releases/3.6.3/workbox-sw.js');

const oneDay = 24 * 60 * 60;

const FALLBACK_HTML_URL = '/offline';

// Clear old cache
self.addEventListener('activate', (event) => {
    const promiseChain = caches.keys()
    .then((cacheNames) => {
        return Promise.all(
            cacheNames.map((cacheName) => {
                if(!cacheName.includes(version)) {
                    caches.delete(cacheName) ;
                }
            })
        );
    });

    event.waitUntil(promiseChain);
});

// enable debugging
workbox.setConfig({ debug: true });

// enable offline analytics
workbox.googleAnalytics.initialize();

workbox.skipWaiting();
workbox.clientsClaim();

// Precache resources
workbox.precaching.precacheAndRoute(
    ['/', '/offline'],
    { offlinePage: '/offline' }
);

// Runtime cache

/**
* Pages to cache start
*/
workbox.routing.registerRoute(/\/brands|\/offers|\/about-us-mobile|\/terms-and-conditions-mobile|\/our-policies-mobile|\/privacy-policy-mobile|\/faqs|\/storelocator|\/eye-care|\/franchise|\/bulkenquiry|\/free-eye-test|\/refer-and-earn/,
  async ({event}) => {
    try {
      return await workbox.strategies.staleWhileRevalidate({
          cacheName: 'cache-pages'
      }).handle({event});
    } catch (error) {
      return caches.match(FALLBACK_HTML_URL);
    }
  }
);
/* ---------- Pages ends ----------*/

workbox.routing.registerRoute(
    '/',
    workbox.strategies.staleWhileRevalidate({
        cacheName: 'homepage-cache__' + version
    })
);
workbox.routing.registerRoute(
    /\/media\/catalog.*\.(?:png|gif|jpg|jpeg|svg)$/,
    new workbox.strategies.CacheFirst({
        cacheName: 'catalog-images-cache__' + version,
        plugins: [
            new workbox.expiration.Plugin({
                maxEntries: 60,
                maxAgeSeconds: 30 * oneDay,
                purgeOnQuotaError: true,
            })
        ],
    })
);
workbox.routing.registerRoute(
    /\/img\/resize.*\.(?:png|gif|jpg|jpeg|svg)$/,
    new workbox.strategies.CacheFirst({
        cacheName: 'resized-images-cache__' + version,
        plugins: [
            new workbox.expiration.Plugin({
                maxEntries: 60,
                maxAgeSeconds: 30 * oneDay,
                purgeOnQuotaError: true,
            })
        ],
    })
);
workbox.routing.registerRoute(
    /\.(?:png|gif|jpg|jpeg|svg)$/,
    new workbox.strategies.CacheFirst({
        cacheName: 'images-cache__' + version,
        plugins: [
            new workbox.expiration.Plugin({
                maxEntries: 60,
                maxAgeSeconds: 30 * oneDay,
                purgeOnQuotaError: true,
            })
        ],
    })
);
workbox.routing.registerRoute(
    /.*\.css/,
    workbox.strategies.cacheFirst({
        cacheName: 'css-cache__' + version,
        plugins: [
            new workbox.expiration.Plugin({
                maxAgeSeconds: 15 * oneDay,
                purgeOnQuotaError: true,
            })
        ],
    })
);
workbox.routing.registerRoute(
    /.*\.js/,
    workbox.strategies.cacheFirst({
        cacheName: 'js-cache__' + version,
        plugins: [
            new workbox.expiration.Plugin({
                maxAgeSeconds: 15 * oneDay,
                purgeOnQuotaError: true,
            })
        ],
    })
);
workbox.routing.registerRoute(
    /\.(?:ttf|woff|woff2)$/,
    workbox.strategies.cacheFirst({
        cacheName: 'fonts-cache__' + version,
        plugins: [
            new workbox.expiration.Plugin({
                maxEntries: 30,
                maxAgeSeconds: 30 * oneDay,
                purgeOnQuotaError: true,
            })
        ]
    })
);
workbox.routing.registerRoute(
    /\/admin\.*/,
    new workbox.strategies.NetworkOnly()
);
workbox.routing.registerRoute(
    /.*\.html/,
    workbox.strategies.staleWhileRevalidate({
        cacheName: 'html-cache__' + version,
        plugins: [
            new workbox.expiration.Plugin({
                maxEntries: 30,
                maxAgeSeconds: 7 * oneDay,
                purgeOnQuotaError: true,
            })
        ],
    })
);

// Handle offline responses
workbox.routing.setCatchHandler(({event}) => {
  // The FALLBACK_URL entries must be added to the cache ahead of time, either via runtime
  // or precaching.
  // If they are precached, then call workbox.precaching.getCacheKeyForURL(FALLBACK_URL)
  // to get the correct cache key to pass in to caches.match().
  //
  // Use event, request, and url to figure out how to respond.
  // One approach would be to use request.destination, see
  // https://medium.com/dev-channel/service-worker-caching-strategies-based-on-request-types-57411dd7652c
  switch (event.request.destination) {
    case 'document':
      return caches.match(FALLBACK_HTML_URL);
    break;

    case 'image':
      return caches.match(FALLBACK_HTML_URL);
    break;

    case 'font':
      return caches.match(FALLBACK_HTML_URL);
    break;

    default:
      // If we don't have a fallback, just return an error response.
      return Response.error();
  }
});