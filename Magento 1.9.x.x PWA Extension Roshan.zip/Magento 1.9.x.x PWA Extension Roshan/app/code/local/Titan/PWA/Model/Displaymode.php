<?php
class Titan_PWA_Model_Displaymode
{
    public function toOptionArray()
    {
      return array(
            array(
                'value' => 'browser',
                'label' => 'Browser',
            ),
            array(
                'value' => 'standalone',
                'label' => 'Standalone',
            ),
            array(
                'value' => 'minimal-ui',
                'label' => 'Minimal UI',
            ),
            array(
                'value' => 'fullscreen',
                'label' => 'Fullscreen',
            ),
        );
    }
}