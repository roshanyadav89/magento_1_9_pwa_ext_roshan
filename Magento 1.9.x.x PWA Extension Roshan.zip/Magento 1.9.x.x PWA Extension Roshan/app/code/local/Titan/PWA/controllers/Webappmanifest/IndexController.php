<?php
class Titan_PWA_Webappmanifest_IndexController extends Mage_Core_Controller_Front_Action
{
    /**
    * sends json response
    */
    public function indexAction()
    {
        /**
        * Get the helper Data.
        *
        * @return Titan_PWA_Helper_Data
        */
        $oManifestModel = Mage::helper("pwa/data")->getData();

        /** @var Mage_Core_Controller_Response_Http $oResponse */
        $oResponse = $this->getResponse();
        $oResponse->setHeader('Content-type', 'text/json');
        $oResponse->setBody(json_encode($oManifestModel, JSON_UNESCAPED_SLASHES));
    }
}